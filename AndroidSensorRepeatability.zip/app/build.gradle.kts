plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "fi.sensorlab.repeatability"
    compileSdk = 35
    defaultConfig {
        applicationId = "fi.sensorlab.repeatability"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
