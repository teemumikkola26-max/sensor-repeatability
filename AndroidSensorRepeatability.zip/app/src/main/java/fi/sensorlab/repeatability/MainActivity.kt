package fi.sensorlab.repeatability

import android.app.Activity
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : Activity(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var rotationSensor: Sensor? = null
    private lateinit var statusText: TextView
    private lateinit var readingText: TextView
    private lateinit var statsText: TextView
    private lateinit var logText: TextView

    private var calibrated = false
    private var reference = DoubleArray(3)
    private var current = DoubleArray(3)
    private var recording = false
    private var startNanos = 0L
    private val samples = mutableListOf<String>()
    private var lastSampleMs = 0L
    private val rotationMatrix = FloatArray(9)
    private val orientation = FloatArray(3)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        buildUi()
        statusText.text = if (rotationSensor != null) {
            "Anturi: Rotation Vector saatavilla"
        } else {
            "Rotation Vector ei ole saatavilla tällä laitteella."
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        fun label(text: String, size: Float = 16f): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setPadding(0, 8, 0, 8)
            }
        statusText = label("Etsitään anturia…", 16f)
        readingText = label("Asento odottaa anturidataa", 20f)
        statsText = label("Kalibroi vertailuasento ja tee palautustestejä.")
        logText = label("Tallennettuja näytteitä: 0")
        content.addView(label("Puhelimen asennon toistettavuustesti", 22f))
        content.addView(statusText)
        content.addView(readingText)
        content.addView(statsText)

        val calibrate = Button(this).apply {
            text = "Aseta vertailuasento"
            setOnClickListener {
                reference = current.copyOf()
                calibrated = true
                updateDisplay()
            }
        }
        val start = Button(this).apply {
            text = "Aloita mittausten tallennus"
            setOnClickListener {
                samples.clear()
                samples.add("elapsed_ms,roll_deg,pitch_deg,yaw_deg,delta_roll_deg,delta_pitch_deg,delta_yaw_deg")
                startNanos = System.nanoTime()
                lastSampleMs = 0L
                recording = true
                logText.text = "Tallennus käynnissä…"
            }
        }
        val stop = Button(this).apply {
            text = "Lopeta tallennus"
            setOnClickListener {
                recording = false
                logText.text = "Tallennettuja näytteitä: ${samples.size - 1}"
            }
        }
        val export = Button(this).apply {
            text = "Vie CSV-tiedostoksi"
            setOnClickListener {
                recording = false
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "text/csv"
                    putExtra(Intent.EXTRA_TITLE, "sensor_repeatability.csv")
                }
                startActivityForResult(intent, 1001)
            }
        }
        listOf(calibrate, start, stop, export).forEach { content.addView(it) }
        content.addView(logText)
        content.addView(label(
            "Testiohje:\n" +
            "1. Aseta puhelin vakaalle alustalle ja odota lukeman rauhoittumista.\n" +
            "2. Paina vertailuasennon asetusta.\n" +
            "3. Tallenna näytteitä, liikuta puhelinta ja palauta se samaan asentoon.\n" +
            "4. Tarkastele CSV-tiedostosta kulmia ja poikkeamia.\n\n" +
            "Huomio: tämä on yleinen anturitesti. Tulokset riippuvat kalibroinnista, " +
            "ympäristön magneettisista häiriöistä ja laitteen antureista. Sovellus ei " +
            "takaa absoluuttista tai virheetöntä asennonmittausta.", 14f
        ))
        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        rotationSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    override fun onPause() {
        sensorManager.unregisterListener(this)
        super.onPause()
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ROTATION_VECTOR) return
        SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
        SensorManager.getOrientation(rotationMatrix, orientation)
        current = DoubleArray(3) { Math.toDegrees(orientation[it].toDouble()) }
        updateDisplay()

        val nowMs = (System.nanoTime() - startNanos) / 1_000_000L
        if (recording && nowMs - lastSampleMs >= 50L) {
            lastSampleMs = nowMs
            val delta = if (calibrated) DoubleArray(3) { wrap(current[it] - reference[it]) }
                        else doubleArrayOf(Double.NaN, Double.NaN, Double.NaN)
            samples.add(
                listOf(nowMs, current[0], current[1], current[2], delta[0], delta[1], delta[2])
                    .joinToString(",") { if (it is Number) "%.5f".format(Locale.US, it.toDouble()) else it.toString() }
            )
            logText.text = "Tallennettuja näytteitä: ${samples.size - 1}"
        }
    }

    private fun wrap(value: Double): Double {
        var x = value
        while (x > 180) x -= 360
        while (x < -180) x += 360
        return x
    }

    private fun updateDisplay() {
        val delta = if (calibrated) DoubleArray(3) { wrap(current[it] - reference[it]) } else null
        readingText.text = String.format(
            Locale.US,
            "Roll: %.2f°\nPitch: %.2f°\nYaw: %.2f°",
            current[2], current[1], current[0]
        )
        statsText.text = if (delta != null) {
            String.format(
                Locale.US,
                "Poikkeama vertailuasennosta:\nRoll: %.2f°\nPitch: %.2f°\nYaw: %.2f°",
                delta[2], delta[1], delta[0]
            )
        } else {
            "Aseta vertailuasento, niin poikkeama näytetään."
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        statusText.text = when (accuracy) {
            SensorManager.SENSOR_STATUS_ACCURACY_HIGH -> "Anturin ilmoittama tarkkuus: hyvä"
            SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM -> "Anturin ilmoittama tarkkuus: keskitaso"
            SensorManager.SENSOR_STATUS_ACCURACY_LOW -> "Anturin ilmoittama tarkkuus: heikko"
            else -> "Anturin tarkkuustila ei ole määritetty"
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == Activity.RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { writer ->
                    writer.write(samples.joinToString("\n"))
                    writer.write("\n")
                }
                logText.text = "CSV tallennettu. Näytteitä: ${samples.size - 1}"
            } catch (e: Exception) {
                logText.text = "CSV-tallennus epäonnistui: ${e.message}"
            }
        }
    }
}
