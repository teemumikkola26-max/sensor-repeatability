package fi.sensorlab.repeatability

import android.app.Activity
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale
import kotlin.math.acos
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class MainActivity : Activity(), SensorEventListener {
    private lateinit var sm: SensorManager
    private var rotationSensor: Sensor? = null
    private lateinit var status: TextView
    private lateinit var live: TextView
    private lateinit var testInfo: TextView
    private lateinit var logInfo: TextView
    private lateinit var driftInfo: TextView

    // Quaternion order is [w, x, y, z].
    private var currentQ = doubleArrayOf(1.0, 0.0, 0.0, 0.0)
    private var filteredQ = doubleArrayOf(1.0, 0.0, 0.0, 0.0)
    private var referenceQ: DoubleArray? = null
    private var hasReading = false
    private var recording = false
    private var driftRunning = false
    private var driftStartNs = 0L
    private var lastCsvNs = 0L
    private var csvStartNs = 0L
    private var emaAlpha = 0.18
    private val csv = mutableListOf<String>()
    private val trialResults = mutableListOf<Trial>()
    private var trialCapture = false
    private var trialStartNs = 0L
    private var trialCount = 0
    private var trialQuatSum = DoubleArray(4)
    private var trialQuatN = 0
    private var trialAnchor: DoubleArray? = null
    private var driftAngles = mutableListOf<Double>()
    private var lastUiNs = 0L

    data class Trial(val number: Int, val timestampMs: Long, val q: DoubleArray, val deviationDeg: Double)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sm = getSystemService(SENSOR_SERVICE) as SensorManager
        rotationSensor = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        buildUi()
        status.text = if (rotationSensor != null) {
            "Rotation Vector käytettävissä · odotetaan anturidataa"
        } else {
            "Rotation Vector -anturia ei löytynyt."
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 18, 24, 24)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun text(s: String, size: Float = 15f) = TextView(this).apply {
            text = s; textSize = size; setPadding(0, 7, 0, 7)
        }
        fun button(s: String, action: () -> Unit) = Button(this).apply {
            text = s; setOnClickListener { action() }
        }
        content.addView(text("Sensor Repeatability 2.0", 24f))
        content.addView(text("Yleiskäyttöinen asennon mittaus- ja toistettavuustesti."))
        status = text("Anturia alustetaan…")
        live = text("Asentoa ei vielä saatavilla", 19f)
        testInfo = text("Kalibroi puhelimen nykyinen asento ennen testejä.")
        driftInfo = text("Drift-testi ei ole käynnissä.")
        logInfo = text("CSV-näytteitä: 0")
        content.addView(status)
        content.addView(text("REAALIAIKAINEN MITTAUS", 17f))
        content.addView(live)
        content.addView(button("Kalibroi vertailuasento") {
            if (hasReading) {
                referenceQ = currentQ.copyOf()
                driftAngles.clear()
                testInfo.text = "Vertailuasento tallennettu."
                refresh()
            } else testInfo.text = "Odota, että anturidata alkaa ennen kalibrointia."
        })
        content.addView(button("Nollaa vertailuasento") { referenceQ = null; refresh() })
        content.addView(text("TOISTETTAVUUSTESTI", 17f))
        content.addView(text("Kalibroi ensin. Jokaisella painalluksella sovellus kerää noin 2 sekunnin asentonäytteet. Irrota ja kiinnitä puhelin uudelleen ennen seuraavaa painallusta. Tavoite 30 toistoa."))
        content.addView(button("Aloita uusi 30 toiston testi") {
            trialResults.clear(); trialCount = 0; trialCapture = false; trialAnchor = referenceQ?.copyOf()
            testInfo.text = if (trialAnchor == null) "Kalibroi ensin vertailuasento." else "Testi valmis aloitettavaksi: 0/30. Kiinnitä puhelin ja paina Tallenna toisto."
            refresh()
        })
        content.addView(button("Tallenna toisto (2 s)") { startTrial() })
        content.addView(button("Tyhjennä toistotulokset") {
            trialResults.clear(); trialCount = 0; trialCapture = false; testInfo.text = "Toistotulokset tyhjennetty."; refresh()
        })
        content.addView(testInfo)
        content.addView(text("DRIFT-TESTI", 17f))
        content.addView(text("Aseta puhelin vakaasti paikalleen, kalibroi ja käynnistä testi. Älä liikuta laitetta testin aikana."))
        content.addView(button("Käynnistä drift-testi") {
            if (referenceQ == null) driftInfo.text = "Kalibroi ensin vertailuasento."
            else { driftRunning = true; driftStartNs = SystemClock.elapsedRealtimeNanos(); driftAngles.clear(); driftInfo.text = "Drift-testi käynnissä…" }
            refresh()
        })
        content.addView(button("Pysäytä drift-testi") { driftRunning = false; updateDriftText() })
        content.addView(driftInfo)
        content.addView(text("RAAKADATA JA CSV", 17f))
        content.addView(button("Aloita jatkuva CSV-tallennus") {
            csv.clear(); csv.add("elapsed_ms,qw,qx,qy,qz,filtered_qw,filtered_qx,filtered_qy,filtered_qz,relative_angle_deg,filtered_relative_angle_deg,drift_running")
            recording = true; csvStartNs = SystemClock.elapsedRealtimeNanos(); lastCsvNs = csvStartNs; logInfo.text = "CSV-tallennus käynnissä."
        })
        content.addView(button("Lopeta CSV-tallennus") { recording = false; logInfo.text = "CSV-näytteitä: ${csv.size - 1}" })
        content.addView(button("Vie mittaus-CSV") { exportCsv() })
        content.addView(button("Vie toistotulokset-CSV") { exportTrials() })
        content.addView(logInfo)
        content.addView(text("Huomio: Rotation Vector on Androidin anturifuusion tulos. Kvaternionivertailu laskee kahden mitatun asennon välisen kulmaeron, mutta ei poista anturien, magneettikentän tai kiinnityksen virheitä. Testi arvioi koko mittausketjun toistettavuutta." , 13f))
        scroll.addView(content)
        root.addView(scroll, ViewGroup.LayoutParams(-1, -1))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        rotationSensor?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }
    override fun onPause() { sm.unregisterListener(this); super.onPause() }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ROTATION_VECTOR) return
        val qf = FloatArray(4)
        SensorManager.getQuaternionFromVector(qf, event.values)
        currentQ = normalize(DoubleArray(4) { qf[it].toDouble() })
        if (!hasReading) { filteredQ = currentQ.copyOf(); hasReading = true }
        else filteredQ = slerp(filteredQ, currentQ, emaAlpha)

        val now = SystemClock.elapsedRealtimeNanos()
        val ref = referenceQ
        if (driftRunning && ref != null) driftAngles.add(angleBetween(ref, currentQ))
        if (trialCapture) {
            val aligned = alignTo(currentQ, trialAnchor ?: currentQ)
            for (i in 0..3) trialQuatSum[i] += aligned[i]
            trialQuatN++
            if (now - trialStartNs >= 2_000_000_000L) finishTrial(now)
        }
        if (recording && now - lastCsvNs >= 50_000_000L) {
            lastCsvNs = now
            val elapsed = (now - csvStartNs) / 1_000_000L
            val d1 = ref?.let { angleBetween(it, currentQ) } ?: Double.NaN
            val d2 = ref?.let { angleBetween(it, filteredQ) } ?: Double.NaN
            csv.add((listOf(elapsed.toDouble()) + currentQ.toList() + filteredQ.toList() + listOf(d1, d2, if (driftRunning) 1.0 else 0.0)).joinToString(",") { fmt(it) })
            logInfo.text = "CSV-näytteitä: ${csv.size - 1}"
        }
        if (now - lastUiNs > 100_000_000L) { lastUiNs = now; refresh() }
    }

    private fun startTrial() {
        if (referenceQ == null) { testInfo.text = "Kalibroi ensin vertailuasento."; return }
        if (!hasReading) { testInfo.text = "Anturidataa ei ole vielä saatavilla."; return }
        if (trialCapture) { testInfo.text = "Toiston mittaus on jo käynnissä."; return }
        if (trialResults.size >= 30) { testInfo.text = "30 toistoa on jo tallennettu. Aloita uusi testi, jos haluat uusia mittaukset."; return }
        if (trialResults.isEmpty()) trialAnchor = referenceQ!!.copyOf()
        trialQuatSum = DoubleArray(4); trialQuatN = 0; trialStartNs = SystemClock.elapsedRealtimeNanos(); trialCapture = true
        testInfo.text = "Kerätään toiston ${trialResults.size + 1}/30 näytteitä 2 sekunnin ajan…"
    }

    private fun finishTrial(now: Long) {
        trialCapture = false
        if (trialQuatN == 0) { testInfo.text = "Toisto epäonnistui: näytteitä ei saatu."; return }
        val q = normalize(trialQuatSum)
        val anchor = trialAnchor ?: referenceQ ?: q
        val dev = angleBetween(anchor, q)
        trialResults.add(Trial(trialResults.size + 1, (now - trialStartNs) / 1_000_000L, q, dev))
        trialCount = trialResults.size
        val values = trialResults.map { it.deviationDeg }
        val mean = values.average()
        val sd = if (values.size > 1) sqrt(values.sumOf { (it - mean) * (it - mean) } / (values.size - 1)) else 0.0
        testInfo.text = String.format(Locale.US,
            "Toisto ${trialResults.size}/30 valmis\nPoikkeama tästä vertailusta: %.4f°\nKeskiarvo: %.4f° · keskihajonta: %.4f° · suurin: %.4f°\nPaina uudelleen vasta, kun puhelin on irrotettu ja kiinnitetty uudelleen.", dev, mean, sd, values.maxOrNull() ?: 0.0)
    }

    private fun refresh() {
        if (!hasReading) return
        val ref = referenceQ
        val angle = ref?.let { angleBetween(it, currentQ) }
        val filteredAngle = ref?.let { angleBetween(it, filteredQ) }
        val e = eulerDegrees(currentQ); val ef = eulerDegrees(filteredQ)
        live.text = String.format(Locale.US,
            "Asento (roll / pitch / yaw):\n%.3f° / %.3f° / %.3f°\n\nVertailupoikkeama: %s\nSuodatettu poikkeama: %s\nSuodatettu asento: %.3f° / %.3f° / %.3f°\nSuodatus α = %.2f",
            e[0], e[1], e[2], angle?.let { "%.4f°".format(Locale.US, it) } ?: "ei kalibroitu",
            filteredAngle?.let { "%.4f°".format(Locale.US, it) } ?: "ei kalibroitu", ef[0], ef[1], ef[2], emaAlpha)
        status.text = "Rotation Vector · ${if (hasReading) "anturidata vastaanotettu" else "odotetaan"}"
        if (driftRunning) updateDriftText()
    }

    private fun updateDriftText() {
        if (driftAngles.isEmpty()) { driftInfo.text = if (driftRunning) "Drift-testi käynnissä; odotetaan näytteitä." else "Drift-testi ei ole käynnissä."; return }
        val mean = driftAngles.average(); val sd = sqrt(driftAngles.sumOf { (it - mean) * (it - mean) } / driftAngles.size)
        val elapsed = (SystemClock.elapsedRealtimeNanos() - driftStartNs) / 1e9
        driftInfo.text = String.format(Locale.US, "Drift-testi %s · %.1f s\nNäytteitä: %d · keskimääräinen poikkeama: %.4f° · keskihajonta: %.4f° · suurin: %.4f°",
            if (driftRunning) "käynnissä" else "pysäytetty", elapsed, driftAngles.size, mean, sd, driftAngles.maxOrNull() ?: 0.0)
    }

    private fun exportCsv() {
        recording = false
        if (csv.size <= 1) { logInfo.text = "Ei mittausdataa vietäväksi. Aloita ensin CSV-tallennus."; return }
        createCsv("sensor_repeatability_measurements.csv", csv.joinToString("\n"))
    }
    private fun exportTrials() {
        if (trialResults.isEmpty()) { testInfo.text = "Ei toistotuloksia vietäväksi."; return }
        val rows = mutableListOf("trial,timestamp_ms,qw,qx,qy,qz,deviation_deg")
        trialResults.forEach { t -> rows.add((listOf(t.number.toDouble(), t.timestampMs.toDouble()) + t.q.toList() + listOf(t.deviationDeg)).joinToString(",") { fmt(it) }) }
        createCsv("sensor_repeatability_trials.csv", rows.joinToString("\n"))
    }
    private fun createCsv(name: String, content: String) {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "text/csv"; putExtra(Intent.EXTRA_TITLE, name) }
        pendingExport = content
        @Suppress("DEPRECATION") startActivityForResult(i, 1001)
    }
    private var pendingExport: String? = null
    @Deprecated("Deprecated in Android API; retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try { contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(pendingExport ?: "") }; logInfo.text = "CSV-tiedosto tallennettu." }
            catch (e: Exception) { logInfo.text = "CSV-tallennus epäonnistui: ${e.message}" }
        }
        pendingExport = null
    }

    private fun angleBetween(a: DoubleArray, b: DoubleArray): Double {
        val an = normalize(a); val bn = normalize(b)
        val dot = abs((0..3).sumOf { an[it] * bn[it] }).coerceIn(-1.0, 1.0)
        return Math.toDegrees(2.0 * acos(dot))
    }
    private fun normalize(q: DoubleArray): DoubleArray {
        val n = sqrt(q.sumOf { it * it }).coerceAtLeast(1e-15)
        return DoubleArray(4) { q[it] / n }
    }
    private fun alignTo(q: DoubleArray, anchor: DoubleArray): DoubleArray {
        val dot = (0..3).sumOf { q[it] * anchor[it] }
        return if (dot < 0) DoubleArray(4) { -q[it] } else q.copyOf()
    }
    private fun slerp(a0: DoubleArray, b0: DoubleArray, t: Double): DoubleArray {
        val a = normalize(a0); var b = normalize(b0)
        var dot = (0..3).sumOf { a[it] * b[it] }
        if (dot < 0) { b = DoubleArray(4) { -b[it] }; dot = -dot }
        if (dot > 0.9995) return normalize(DoubleArray(4) { a[it] + t * (b[it] - a[it]) })
        val theta = acos(dot.coerceIn(-1.0, 1.0)); val sinTheta = kotlin.math.sin(theta)
        val wa = kotlin.math.sin((1 - t) * theta) / sinTheta; val wb = kotlin.math.sin(t * theta) / sinTheta
        return normalize(DoubleArray(4) { wa * a[it] + wb * b[it] })
    }
    private fun eulerDegrees(q: DoubleArray): DoubleArray {
        val w=q[0]; val x=q[1]; val y=q[2]; val z=q[3]
        val roll = kotlin.math.atan2(2*(w*x+y*z), 1-2*(x*x+y*y))
        val sinp = 2*(w*y-z*x)
        val pitch = if (abs(sinp) >= 1) Math.copySign(Math.PI/2, sinp) else kotlin.math.asin(sinp)
        val yaw = kotlin.math.atan2(2*(w*z+x*y), 1-2*(y*y+z*z))
        return doubleArrayOf(Math.toDegrees(roll), Math.toDegrees(pitch), Math.toDegrees(yaw))
    }
    private fun fmt(v: Double): String = if (v.isFinite()) String.format(Locale.US, "%.7f", v) else ""
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        status.text = "Anturin ilmoittama tarkkuustila: " + when (accuracy) {
            SensorManager.SENSOR_STATUS_ACCURACY_HIGH -> "hyvä"
            SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM -> "keskitaso"
            SensorManager.SENSOR_STATUS_ACCURACY_LOW -> "heikko"
            else -> "ei määritetty"
        }
    }
}
