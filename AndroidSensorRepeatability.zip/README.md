# Sensor Repeatability 2.0

Android app for general-purpose phone orientation repeatability testing using Android's Rotation Vector sensor.

Features:
- Quaternion-based angular deviation from a calibrated reference.
- Live raw and smoothed readings (spherical linear interpolation).
- 30-trial reattachment test: each trial averages approximately 2 seconds of quaternion samples.
- Drift test while the phone remains stationary.
- Continuous measurement CSV export and separate trial-results CSV export.

Build with Android Gradle Plugin 8.6.1, Gradle 8.7, Java 17, compile SDK 35. The cloud workflow should unpack this ZIP and overwrite app/build.gradle.kts with Java/Kotlin target 17 settings before running `gradle assembleDebug`.

Note: test results include sensor fusion, magnetic environment, device mounting and handling effects. They are not a calibration certificate or guarantee of absolute orientation accuracy.
