# Android Sensor Repeatability Test

A minimal Android Studio project for general-purpose phone orientation sensor testing.

## Open and run
1. Install Android Studio.
2. Open this folder as an existing project.
3. Let Gradle sync.
4. Connect the Android phone with USB debugging enabled.
5. Run the `app` configuration.

## What it measures
- Android `TYPE_ROTATION_VECTOR` orientation converted to roll/pitch/yaw.
- A user-set reference orientation.
- Wrapped angular differences from that reference.
- Time-stamped CSV samples at approximately 20 Hz.

## Important limitations
- Euler angles can be unintuitive near angle wraparound and singularities.
- The sensor's orientation estimate depends on device hardware, Android's sensor fusion, calibration, and magnetic environment.
- The app is a practical repeatability test, not a metrology instrument and not a guarantee of drift-free absolute orientation.
- For rigorous analysis, repeat trials under controlled conditions and compare distributions, not just a single reading.
